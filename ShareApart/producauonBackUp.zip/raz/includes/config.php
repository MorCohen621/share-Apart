<?php
 
define('DB_HOST','localhost');
define('DB_USER','isshaneemo');
define('DB_PASS','shanee123');
define('DB_NAME','isshanee_shareApart_new');
?>